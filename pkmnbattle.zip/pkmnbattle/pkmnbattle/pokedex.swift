//
//  pokedex.swift
//  pkmnbattle
//
//  Created by SwiftPlayer on 12/02/2022.
//

import SwiftUI

struct pokedex: View {
    
    @State var pokemonImg = ["pikachu_f", "torchic_f", "mudkip_f", "treecko_f"]
    @State var pokemonName = ["Pikachu", "Torchic", "Mudkip", "Treecko"]
    

    var body: some View {
     NavigationView{
        ZStack{
        List{
            ForEach(Array(zip(pokemonImg, pokemonName)), id: \.0) { poke in
                HStack{
                    Image("\(poke.0)")
                              .resizable()
                              .frame( width: 50, height: 50)
                              .padding(.trailing, 25)
                        
                    Text("\(poke.1)")
                    
                    
                }
             }
        }
        .navigationTitle("Pokédex")
            
            
        }
     }
}


struct pokedex_Previews: PreviewProvider {
    static var previews: some View {
        pokedex()
    }
}
}
