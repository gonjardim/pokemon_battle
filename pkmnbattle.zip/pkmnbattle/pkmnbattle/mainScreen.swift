//
//  mainScreen.swift
//  pkmnbattle
//
//  Created by SwiftPlayer on 10/02/2022.
//

import SwiftUI

struct mainScreen: View {
    var body: some View {
        NavigationView{
            
        ZStack(){
            Spacer().frame(width: UIScreen.main.bounds.size.width*1.00, height: UIScreen.main.bounds.size.height*1.02, alignment: .leading)
            VStack(){
                Image("pokemon_logo").resizable().frame(width:UIScreen.main.bounds.size.width*0.90, height:UIScreen.main.bounds.size.height*0.25)
                .offset(y:UIScreen.main.bounds.size.height*(-0.05))
                    
                HStack{
                    
                            NavigationLink(
                                destination: ContentView(),
                                label: {
                                    Text("Play")
                                        .fontWeight(.heavy)
                                        .background( Rectangle()
                                                        .foregroundColor(.blue)
                                                        .frame(width: 140, height: 60)
                                                        .clipShape(Capsule()))
                                    .foregroundColor(.white)
                                    
                                })
                            }
                
                Spacer().frame(height: UIScreen.main.bounds.size.height*0.07, alignment: .leading)
                
                HStack{
                    
                            NavigationLink(
                                destination: pokedex(),
                                label: {
                                    Text("Pokédex")
                                        .fontWeight(.heavy)
                                        .background( Rectangle()
                                                        .foregroundColor(.blue)
                                                        .frame(width: 140, height: 60)
                                                        .clipShape(Capsule()))
                                    .foregroundColor(.white)
                                    
                                })
                            }
            }
            
        }.background(Image("main_screen_background").resizable() .frame(width:UIScreen.main.bounds.size.width*1.05, height:UIScreen.main.bounds.size.height*1.16))
    }.frame(height: UIScreen.main.bounds.size.height*1.00, alignment: .leading)
        
        
}
}



struct mainScreen_Previews: PreviewProvider {
    static var previews: some View {
        mainScreen()
    }
}

