//
//  ContentView.swift
//  pkmnbattle
//
//  Created by SwiftPlayer on 10/12/2021.
//

import SwiftUI
import UIKit

struct ContentView: View {
    @State var pokemon = ["pikachu", "torchic", "mudkip", "treecko"]
    @State var pokemonImg = ["pikachu_b", "torchic_b", "mudkip_b", "treecko_b"]
    @State var pokemonEnemyImg = ["pikachu_f", "torchic_f", "mudkip_f", "treecko_f"]
    @State var pokemonMoves = ["thundershock" : "40", "ember" : "40", "water gun" : "40", "absorb" : "20"]
    @State var pokemonStats = [String]()
    @State var pikachu = ["pikachu", "\(300)", "\(15)", "\(10)", "\(1)", "electric", "thundershock"] //name, hp, attack, def, XP, type
    @State var torchic = ["torchic", "\(290)", "\(20)", "\(15)", "\(1)", "fire", "ember"]
    @State var mudkip = ["mudkip", "\(280)", "\(10)", "\(5)", "\(1)", "water", "water gun"]
    @State var treecko = ["treecko", "\(270)", "\(25)", "\(10)", "\(1)", "grass", "absorb"]
    @State var hpEnemy = 300
    @State var pokemonSelect = 0
    @State var pokemonChosen = ""
    @State var randomInt = Int.random(in: 0..<4)
    //@State var hpPlayer:Int
    //@State var attack:Int

    //@State var movePower:Int
    //@State var enemyDef:Int
    var body: some View {
        VStack(){
            Spacer().frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.04, alignment: .leading)
            VStack(){
                HStack(){
                    Text("\(pokemon[randomInt])").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .leading)
                        .offset(y:UIScreen.main.bounds.size.height*0.015)
                        .background(
                            Image("battle_message").offset(x:UIScreen.main.bounds.size.width*(-0.72), y:UIScreen.main.bounds.size.height*0.028))
                }
                HStack(){
                    Text("HP: \(hpEnemy)   lvl: 1").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .leading)
                        .offset(y:UIScreen.main.bounds.size.height*(-0.015))
                    
                    //Text("aaaa").frame().offset(x:UIScreen.main.bounds.size.width*(-0.65), y:UIScreen.main.bounds.size.height*(-0.015))
                }
                
                HStack(){
                    Image("\(pokemonEnemyImg[randomInt])").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .trailing)
                        .background(
                            Image("enemy_base").offset(x:UIScreen.main.bounds.size.width*0.15, y:UIScreen.main.bounds.size.height*0.07))
                }
            }
           
            HStack(){}.frame(height:UIScreen.main.bounds.size.height*0.2)
           
            VStack(){
                HStack(){
                    Text("\(pokemon[pokemonSelect])").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .trailing)
                        .offset(y:UIScreen.main.bounds.size.height*0.015)
                        .background(
                            Image("battle_message").offset(x:UIScreen.main.bounds.size.width*0.72, y:UIScreen.main.bounds.size.height*0.028))
                }
                HStack(){
                    if (pokemon[pokemonSelect]==pikachu[0]){
                        Text("lvl: \(pikachu[4])       HP: \(pikachu[1])").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .trailing)
                            .offset(y:UIScreen.main.bounds.size.height*(-0.015))
                    }
                    else if (pokemon[pokemonSelect]==torchic[0]){
                        Text("lvl: \(torchic[4])       HP: \(torchic[1])").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .trailing)
                            .offset(y:UIScreen.main.bounds.size.height*(-0.015))
                    }
                    else if (pokemon[pokemonSelect]==mudkip[0]){
                        Text("lvl: \(mudkip[4])       HP: \(mudkip[1])").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .trailing)
                            .offset(y:UIScreen.main.bounds.size.height*(-0.015))
                    }
                    else if (pokemon[pokemonSelect]==treecko[0]){
                        Text("lvl: \(treecko[4])       HP: \(treecko[1])").frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .trailing)
                            .offset(y:UIScreen.main.bounds.size.height*(-0.015))
                    }
                }
                HStack(){
                    Image(pokemonImg[pokemonSelect]).frame(width: UIScreen.main.bounds.size.width*0.95, height: UIScreen.main.bounds.size.height*0.06, alignment: .leading)
                        .background(
                            Image("enemy_base").offset(x:UIScreen.main.bounds.size.width*(-0.15), y:UIScreen.main.bounds.size.height*0.06))
                }
            }
            Spacer().frame(height: UIScreen.main.bounds.size.height*0.185)
            VStack(spacing:1){
                HStack(spacing:1){
                    /* 1- not very effective
                       2- normal damage
                       3- very effective */
                    if(pikachu[1]>"\(0)" || torchic[1]>"\(0)" || mudkip[1]>"\(0)" || treecko[1]>"\(0)"){
                    if(pokemon[pokemonSelect]==pikachu[0]){
                        Button(pikachu[6]){
                            if (Int(pikachu[1])! >= 1){
                                if (hpEnemy >= 1){
                                    if (pokemon[randomInt]=="pikachu"){
                                        self.hpEnemy -= ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(pikachu[3])!)) * 1
                                        
                                        self.pikachu[1] = "\(Int(pikachu[1])! - ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(pikachu[3])!)) * 1)"
                                        
                                    } else if (pokemon[randomInt]=="torchic"){
                                        self.hpEnemy -= ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(torchic[3])!)) * 2
                                        
                                        self.pikachu[1] = "\(Int(pikachu[1])! - ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(pikachu[3])!)) * 2)"
                                        
                                    } else if (pokemon[randomInt]=="mudkip"){
                                        self.hpEnemy -= ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(mudkip[3])!)) * 3
                                        
                                        self.pikachu[1] = "\(Int(pikachu[1])! - ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(pikachu[3])!)) * 2)"
                                        
                                    } else if (pokemon[randomInt]=="treecko"){
                                        self.hpEnemy -= ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(treecko[3])!)) * 1
                                        
                                        self.pikachu[1] = "\(Int(pikachu[1])! - ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(pikachu[3])!)) * 2)"
                                        
                                    }
                                } else {
                                    randomInt = Int.random(in: 0..<4)
                                    hpEnemy = 0
                                    hpEnemy = 300
                                    pikachu[4] = "\(1+Int(pikachu[4])!)"
                                    pikachu[1] = "\(300)"
                                    pikachu[2] = "\(2+Int(pikachu[2])!)"
                                    pikachu[3] = "\(1+Int(pikachu[3])!)"
                                    
                                }
                            }else{
                                pikachu[1] = "\(0)"
                            }
                            //self.hpEnemy = ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - 15) * 1


                        }
                            .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                            .overlay(
                            RoundedRectangle(cornerRadius: 1)
                                .stroke(Color.red, lineWidth: 2)
                            )
                            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                            .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                    } else if(pokemon[pokemonSelect]==torchic[0]){
                        Button(torchic[6]){
                            if (Int(torchic[1])! >= 1){
                                if (hpEnemy >= 1){
                                    if (pokemon[randomInt]=="pikachu"){
                                        self.hpEnemy -= ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(pikachu[3])!)) * 2
                                        
                                        self.torchic[1] = "\(Int(torchic[1])! - ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(torchic[3])!)) * 2)"
                                        
                                    } else if (pokemon[randomInt]=="torchic"){
                                        self.hpEnemy -= ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(torchic[3])!)) * 1
                                        
                                        self.torchic[1] = "\(Int(torchic[1])! - ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(torchic[3])!)) * 1)"
                                        
                                    } else if (pokemon[randomInt]=="mudkip"){
                                        self.hpEnemy -= ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(mudkip[3])!)) * 1
                                        
                                        self.torchic[1] = "\(Int(torchic[1])! - ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(torchic[3])!)) * 3)"
                                        
                                    } else if (pokemon[randomInt]=="treecko"){
                                        self.hpEnemy -= ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(treecko[3])!)) * 3
                                        
                                        self.torchic[1] = "\(Int(torchic[1])! - ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(torchic[3])!)) * 1)"
                                    }
                                } else {
                                    randomInt = Int.random(in: 0..<4)
                                    hpEnemy = 300
                                    torchic[4] = "\(1+Int(torchic[4])!)"
                                    torchic[1] = "\(290)"
                                    torchic[2] = "\(2+Int(torchic[2])!)"
                                    torchic[3] = "\(1+Int(torchic[3])!)"
                                    
                                }
                            }else{
                                torchic[1] = "\(0)"
                            }


                        }
                            .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                            .overlay(
                            RoundedRectangle(cornerRadius: 1)
                                .stroke(Color.red, lineWidth: 2)
                            )
                            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                            .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                    } else if(pokemon[pokemonSelect]==mudkip[0]){
                        Button(mudkip[6]){
                            if (Int(mudkip[1])! >= 1){
                                if (hpEnemy >= 1){
                                    if (pokemon[randomInt]=="pikachu"){
                                        self.hpEnemy -= ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(pikachu[3])!)) * 2
                                        
                                        self.mudkip[1] = "\(Int(mudkip[1])! - ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(mudkip[3])!)) * 3)"
                                        
                                    } else if (pokemon[randomInt]=="torchic"){
                                        self.hpEnemy -= ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(torchic[3])!)) * 3
                                        
                                        self.mudkip[1] = "\(Int(mudkip[1])! - ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(mudkip[3])!)) * 1)"
                                        
                                    } else if (pokemon[randomInt]=="mudkip"){
                                        self.hpEnemy -= ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(mudkip[3])!)) * 1
                                        
                                        self.mudkip[1] = "\(Int(mudkip[1])! - ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(mudkip[3])!)) * 1)"
                                        
                                    } else if (pokemon[randomInt]=="treecko"){
                                        self.hpEnemy -= ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(treecko[3])!)) * 1
                                        
                                        self.mudkip[1] = "\(Int(mudkip[1])! - ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(mudkip[3])!)) * 3)"
                                    }
                                } else {
                                    randomInt = Int.random(in: 0..<4)
                                    hpEnemy = 300
                                    mudkip[4] = "\(1+Int(mudkip[4])!)"
                                    mudkip[1] = "\(280)"
                                    mudkip[2] = "\(2+Int(mudkip[2])!)"
                                    mudkip[3] = "\(1+Int(mudkip[3])!)"
                                    
                                }
                            }else{
                                mudkip[1] = "\(0)"
                            }


                        }
                            .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                            .overlay(
                            RoundedRectangle(cornerRadius: 1)
                                .stroke(Color.red, lineWidth: 2)
                            )
                            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                            .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                    } else if(pokemon[pokemonSelect]==treecko[0]){
                        Button(treecko[6]){
                            if (Int(treecko[1])! >= 1){
                                if (hpEnemy >= 1){
                                    if (pokemon[randomInt]=="pikachu"){
                                        self.hpEnemy -= ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(pikachu[3])!)) * 2
                                        
                                        self.treecko[1] = "\(Int(treecko[1])! - ( (Int(pikachu[2])!) + Int( pokemonMoves["thundershock"]!)! - (Int(treecko[3])!)) * 1)"
                                        
                                    } else if (pokemon[randomInt]=="torchic"){
                                        self.hpEnemy -= ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(torchic[3])!)) * 1
                                        
                                        self.treecko[1] = "\(Int(treecko[1])! - ( (Int(torchic[2])!) + Int( pokemonMoves["ember"]!)! - (Int(treecko[3])!)) * 3)"
                                        
                                    } else if (pokemon[randomInt]=="mudkip"){
                                        self.hpEnemy -= ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(mudkip[3])!)) * 3
                                        
                                        self.treecko[1] = "\(Int(treecko[1])! - ( (Int(mudkip[2])!) + Int( pokemonMoves["water gun"]!)! - (Int(treecko[3])!)) * 1)"
                                        
                                    } else if (pokemon[randomInt]=="treecko"){
                                        self.hpEnemy -= ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(treecko[3])!)) * 1
                                        
                                        self.treecko[1] = "\(Int(treecko[1])! - ( (Int(treecko[2])!) + Int( pokemonMoves["absorb"]!)! - (Int(treecko[3])!)) * 1)"
                                    }
                                } else {
                                    randomInt = Int.random(in: 0..<4)
                                    hpEnemy = 300
                                    treecko[4] = "\(1+Int(treecko[4])!)"
                                    treecko[1] = "\(270)"
                                    treecko[2] = "\(2+Int(treecko[2])!)"
                                    treecko[3] = "\(1+Int(treecko[3])!)"
                                    
                                }
                            }else{
                                treecko[1] = "\(0)"
                            }


                        }
                            .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                            .overlay(
                            RoundedRectangle(cornerRadius: 1)
                                .stroke(Color.red, lineWidth: 2)
                            )
                            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                            .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                    }
                    }else{
                        //Text("Game Over")
                        Button("Game Over"){}.frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                            .overlay(
                            RoundedRectangle(cornerRadius: 1)
                                .stroke(Color.red, lineWidth: 2)
                            )
                            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                            .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                    }
                   
                    Button("-"){}
                        .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                        .overlay(
                        RoundedRectangle(cornerRadius: 1)
                            .stroke(Color.yellow, lineWidth: 2)
                        )
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                        .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                   
                    //Button("Pokemon"){
                        Picker("Pokemon", selection: $pokemonSelect){
                            ForEach(0..<pokemon.count){
                                Text(pokemon[$0])
                            }
                        }
                    //}
                        .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                        .overlay(
                        RoundedRectangle(cornerRadius: 1)
                            .stroke(Color.green, lineWidth: 2)
                        )
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.614, saturation: 0.785, brightness: 0.942)/*@END_MENU_TOKEN@*/)
                        .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                }
                HStack(spacing:1){
                    Button("-"){}
                        .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                        .overlay(
                        RoundedRectangle(cornerRadius: 1)
                            .stroke(Color.red, lineWidth: 2)
                        )
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                        .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                   
                    Button("-"){}
                        .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                        .overlay(
                        RoundedRectangle(cornerRadius: 1)
                            .stroke(Color.yellow, lineWidth: 2)
                        )
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 1.0, saturation: 0.533, brightness: 0.93)/*@END_MENU_TOKEN@*/)
                        .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                   
                    Button("Run"){exit(0)}
                        .frame(width: UIScreen.main.bounds.size.width*0.33, height: UIScreen.main.bounds.size.height*0.1)
                        .overlay(
                        RoundedRectangle(cornerRadius: 1)
                            .stroke(Color.green, lineWidth: 2)
                        )
                        .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(hue: 0.614, saturation: 0.785, brightness: 0.942)/*@END_MENU_TOKEN@*/)
                        .foregroundColor(/*@START_MENU_TOKEN@*/.black/*@END_MENU_TOKEN@*/)
                }
                
            }
           
        }.background(Image("battle_background").resizable())
        .offset(y:UIScreen.main.bounds.size.height*(-0.050))
        
       
       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
