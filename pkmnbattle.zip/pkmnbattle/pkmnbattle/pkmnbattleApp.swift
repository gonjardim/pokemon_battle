//
//  pkmnbattleApp.swift
//  pkmnbattle
//
//  Created by SwiftPlayer on 10/12/2021.
//

import SwiftUI

@main
struct pkmnbattleApp: App {
    var body: some Scene {
        WindowGroup {
            mainScreen()
        }
    }
}
